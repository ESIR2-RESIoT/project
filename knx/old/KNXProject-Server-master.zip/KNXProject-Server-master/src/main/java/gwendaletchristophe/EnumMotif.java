package gwendaletchristophe;

public enum EnumMotif {
    
    normal,
    inverse,
    paire,
    maintenu,

}
