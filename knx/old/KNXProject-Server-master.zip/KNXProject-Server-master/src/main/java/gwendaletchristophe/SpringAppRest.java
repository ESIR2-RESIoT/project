package gwendaletchristophe;

import java.io.IOException;


import org.json.JSONObject;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
@RestController
public class SpringAppRest {

    public static ChenillardThread chenillardThread;
    public static KNXConnection knx;
    private static Boolean modeDev = false;
    private static SpringApplication application;

    public static void main(String[] args) throws IOException, InterruptedException {
        if (!modeDev) {
            knx = new KNXConnection("192.168.1.201", chenillardThread);
            //chenillardThread.start();
        }
        application = new SpringApplication(SpringAppRest.class);
        application.run(args);
    }

    @GetMapping("/allumerChenillard")
    public String allumerChenillard() {
        if (!modeDev)
            //chenillardThread.playChenillard();
            knx.demarrerChenillard();
        JSONObject response = new JSONObject();
        if (modeDev)
            System.out.println(response.put("statut", "realise").toString());
        return response.put("statut", "realise").toString();
    }

    @GetMapping("/eteindreChenillard")
    public String eteindreChenillard() {
        if (!modeDev)
            //chenillardThread.stopChenillard();
            knx.arreterChenillard();
        JSONObject response = new JSONObject();
        return response.put("statut", "realise").toString();
    }

    // @GetMapping("/accelererChenillard")
    // public String accelererChenillard() {
    //     if (!modeDev)
    //         chenillardThread.speedUpChenillard();
    //     JSONObject response = new JSONObject();
    //     return response.put("statut", "realise").toString();
    // }

    // @GetMapping("/ralentirChenillard")
    // public String ralentirChenillard() {
    //     if (!modeDev)
    //         chenillardThread.speedDownChenillard();
    //     JSONObject response = new JSONObject();
    //     return response.put("statut", "realise").toString();
    // }

    @GetMapping("/modifierVitesseChenillard")
    public String modifierVitesseChenillard(@RequestParam(value = "vitesse", defaultValue = "600") int vitesse) {
        if (vitesse >= 600 & vitesse <= 2000) {
            if (!modeDev)
                //chenillardThread.editSpeedChenillard(vitesse);
                knx.vitesseChenillard(vitesse);
            JSONObject response = new JSONObject();
            return response.put("statut", "realise").toString();
        } else {
            JSONObject response = new JSONObject();
            response.put("statut", "erreur");
            return response.put("description", "vitesse trop grande/petite").toString();
        }
    }

    @GetMapping("/pauseChenillard")
    public String pauseChenillard() {
        if (!modeDev)
            //chenillardThread.pauseChennillard();
            knx.pauseChenillard();
        JSONObject response = new JSONObject();
        return response.put("statut", "realise").toString();
    }

    @GetMapping("/resumeChenillard")
    public String resumeChenillard() {
        if (!modeDev)
            //chenillardThread.resumeChenillard();
            knx.reprendreChenillard();
        JSONObject response = new JSONObject();
        return response.put("statut", "realise").toString();
    }

    @GetMapping("/reverseChenillard")
    public String reverseChenillard() {
        if (!modeDev)
            //chenillardThread.resumeChenillard();
            knx.reverseChenillard();
        JSONObject response = new JSONObject();
        return response.put("statut", "realise").toString();
    }

    @GetMapping("/allumerLed")
    public String allumerled(@RequestParam(value = "numLED", defaultValue = "1") int numeroLED) {
        if (numeroLED <= 4 & numeroLED >= 1) {
            if (!modeDev)
                knx.writeKNXdata("0/0/" + numeroLED, true);
            JSONObject response = new JSONObject();
            return response.put("statut", "realise").toString();
        } else {
            JSONObject response = new JSONObject();
            response.put("statut", "erreur");
            return response.put("description", "id de led incorrecte").toString();
        }
    }

    @GetMapping("/eteindreLed")
    public String eteindreLed(@RequestParam(value = "numLED", defaultValue = "1") int numeroLED) {
        if (numeroLED <= 4 & numeroLED >= 1) {
            if (!modeDev)
                knx.writeKNXdata("0/0/" + numeroLED, false);
            JSONObject response = new JSONObject();
            return response.put("statut", "réalisé").toString();
        } else {
            JSONObject response = new JSONObject();
            response.put("statut", "erreur");
            return response.put("descritpion", "id de led incorrecte").toString();
        }

    }

    @GetMapping("/majModeDev")
    public String setDevMode(@RequestParam(value = "actif", defaultValue = "false") Boolean actif) {
        if (actif) {
            modeDev = true;
            JSONObject response = new JSONObject();
            return response.put("statut", "modeDevActif").toString();
        } else if (!actif) {
            modeDev = false;
            JSONObject response = new JSONObject();
            return response.put("statut", "modeDevInactif").toString();
        } else {
            JSONObject response = new JSONObject();
            response.put("statut", "erreur");
            return response.put("descritpion", "valeur du boolean incorrecte").toString();
        }
    }

}
