package gwendaletchristophe;

import java.net.InetSocketAddress;

import tuwien.auto.calimero.GroupAddress;
import tuwien.auto.calimero.KNXException;
import tuwien.auto.calimero.link.KNXNetworkLink;
import tuwien.auto.calimero.link.KNXNetworkLinkIP;
import tuwien.auto.calimero.link.medium.TPSettings;
import tuwien.auto.calimero.process.ProcessCommunicator;
import tuwien.auto.calimero.process.ProcessCommunicatorImpl;

public class KNXConnection {

    private KNXNetworkLink knxLink;
    private ProcessCommunicator pc;
    private ChenillardThread chenillardThread;

    public KNXConnection(String ip, ChenillardThread chenillardThread) {
        InetSocketAddress socket = new InetSocketAddress(ip, 3671);
        try {
            chenillardThread = new ChenillardThread(this);
            this.knxLink = KNXNetworkLinkIP.newTunnelingLink(null, socket, false, new TPSettings());
            this.chenillardThread = chenillardThread;
            this.chenillardThread.start();
            this.pc = new ProcessCommunicatorImpl(knxLink) {
            };
            pc.addProcessListener(new KNXListener(chenillardThread, SocketHandler.getInstance()));
        } catch (KNXException | InterruptedException e1) {
            e1.printStackTrace();
        }
    }

    public void pauseChenillard(){
        chenillardThread.pauseChennillard();
    }

    public void demarrerChenillard(){
        chenillardThread.playChenillard();
    }
    public void arreterChenillard(){
        chenillardThread.stopChenillard();
    }
    public void reprendreChenillard(){
        chenillardThread.resumeChenillard();
    }
    public void vitesseChenillard(int vitesse){
        chenillardThread.editSpeedChenillard(vitesse);
    }

    public void reverseChenillard(){
        chenillardThread.reverseChenillard();
    }

    public boolean readKNXdata(String group) {
        try {
            boolean result = pc.readBool(new GroupAddress(group));
            //System.out.println("Reading value from " + group + " -> " + result);
            return result;
        } catch (KNXException | InterruptedException e) {
            e.printStackTrace();
        }

        return false;
    }

    public void writeKNXdata(String group, boolean value) {
        try {
            //System.out.println("Writing value " + value + " on group " + group);
            pc.write(new GroupAddress(group), value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void disconnectKNXConnection() {
        System.out.println("Closing KNX connection...");
        pc.close();
        knxLink.close();
    }
}
