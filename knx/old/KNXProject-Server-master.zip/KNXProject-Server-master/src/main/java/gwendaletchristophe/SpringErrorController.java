package gwendaletchristophe;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SpringErrorController implements ErrorController {

    @RequestMapping("/error")
    @ResponseBody
    public String handleError(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
        JSONObject response = new JSONObject();

        if (!String.valueOf(exception).equals(null) & !String.valueOf(exception).equals("null")) {
            System.err.println("Nested Exception: " + String.valueOf(exception));

            response.put("exception", exception.getMessage());
        }

        if (!String.valueOf(statusCode).equals(null) & !String.valueOf(statusCode).equals("null")) {
            System.err.println("Status Code: " + String.valueOf(statusCode));

            response.put("ErreurStatutCode", String.valueOf(statusCode));
        }

        return response.toString();
    }

    @Override
    public String getErrorPath() {
        return "/error";
    }

}
