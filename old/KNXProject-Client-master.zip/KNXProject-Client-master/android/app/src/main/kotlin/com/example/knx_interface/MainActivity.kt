package com.example.knx_interface

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
