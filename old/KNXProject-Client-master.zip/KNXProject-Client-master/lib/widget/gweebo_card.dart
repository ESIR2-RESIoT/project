import 'package:flutter/material.dart';

class GweeboCard extends StatelessWidget {
  final Widget child;

  GweeboCard({@required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(8),
      padding: EdgeInsets.all(3),
      child: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          Container(
            decoration: BoxDecoration(
              border:
                  Border.all(width: 2.0, color: Theme.of(context).accentColor),
              borderRadius: BorderRadius.all(Radius.circular(5)),
              color: Theme.of(context).backgroundColor,
            ),
            child: this.child,
          ),
          Positioned(
              top: -10,
              child: Container(
                height: 15,
                width: 15,
                color: Theme.of(context).accentColor,
              ))
          // CustomPaint(
          //   painter: GweeboCircle(),
          // ),
        ],
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(5)),
        border: Border.all(width: 1.0, color: Theme.of(context).primaryColor),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).primaryColor.withOpacity(0.5),
            spreadRadius: 0.5,
            blurRadius: 7,
            offset: Offset(0, 7), // changes position of shadow
          ),
        ],
        color: Theme.of(context).backgroundColor,
      ),
    );
  }
}

class GweeboCircle extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint1 = Paint()
      ..color = Color(0xFF14213d)
      ..style = PaintingStyle.fill;

    var paint2 = Paint()
      ..color = Color(0xfffca311)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(Offset(1, 0), 10, paint1);
    canvas.drawCircle(Offset(5, 9), 8, paint2);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
