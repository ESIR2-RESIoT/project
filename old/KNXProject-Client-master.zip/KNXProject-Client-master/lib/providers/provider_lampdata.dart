import 'dart:convert';

import 'package:flutter/cupertino.dart';

class ProviderLampData with ChangeNotifier {
  List<bool> lampsValue = [false, false, false, false];

  void changeLampsValue(String json) {
    var data = jsonDecode(json);
    lampsValue[0] = data["Lampe1"];
    lampsValue[1] = data["Lampe2"];
    lampsValue[2] = data["Lampe3"];
    lampsValue[3] = data["Lampe4"];

    notifyListeners();
  }
}
