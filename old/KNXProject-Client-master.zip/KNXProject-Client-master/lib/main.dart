//import 'package:js/js.dart';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:knx_interface/providers/provider_lampdata.dart';
import 'package:knx_interface/request.dart';
import 'package:knx_interface/socket.dart';
import 'package:knx_interface/widget/gweebo_card.dart';
import 'package:provider/provider.dart';
import 'package:simple_animations/simple_animations.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() {
  runApp(MyApp());
}

bool requestStatue = false;
KNXRequest knxRequest = new KNXRequest(url: "http://10.0.2.2:8080");

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Color(0xFF14213d),
        accentColor: Color(0xfffca311),
        backgroundColor: Color(0xffe5e5e5),
      ),
      home: Scaffold(
        drawer: Drawer(
            child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF14213d),
                ),
                child: Text(
                  'Choisir le motif',
                  textScaleFactor: 2,
                  style: TextStyle(color: Colors.white),
                )),
            ListTile(
              title: Text('Chenillard'),
              onTap: () {
                // Update the state of the app.
                // ...
              },
            ),
            Divider(),
            ListTile(
              title: Text('Chenillard inversé'),
              onTap: () {},
            ),
          ],
        )),
        backgroundColor: Color(0xffe5e5e5),
        appBar: AppBar(
          title: Text("KNX Connector"),
        ),
        body: Center(
            child: Column(
          children: [
            Padding(padding: EdgeInsets.only(top: 10)),
            KNXButton(
                title: "Play",
                description: "Démarrer le chenillard",
                logo: Icon(Icons.circle),
                pathToSend: "allumerChenillard"),
            KNXButton(
                title: "Stop",
                description: "Arrêter le chenillard",
                logo: Icon(Icons.stop),
                pathToSend: "eteindreChenillard"),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                KNXButton(
                    title: "Pause",
                    description: "Mettre en pause",
                    logo: Icon(Icons.pause),
                    pathToSend: "pauseChenillard"),
                KNXButton(
                    title: "Resume",
                    description: "Reprendre le chenillard",
                    logo: Icon(Icons.play_arrow),
                    pathToSend: "resumeChenillard"),
              ],
            ),
            KNXSpeedSlider(),
            KNXLamps(),
          ],
        )),
      ),
    );
  }
}

class KNXLamps extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    MySocket.connectSocket();

    return Expanded(
      child: Center(
        child: StreamBuilder(
          stream: MySocket.socket.stream,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              var data = jsonDecode(snapshot.data);
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  KNXLamp(data["Lampe1"]),
                  KNXLamp(data["Lampe2"]),
                  KNXLamp(data["Lampe3"]),
                  KNXLamp(data["Lampe4"]),
                ],
              );
            } else
              return CircularProgressIndicator();
          },
        ),
      ),
    );
  }
}

class KNXLamp extends StatelessWidget {
  final bool isOn;

  KNXLamp(this.isOn);

  @override
  Widget build(BuildContext context) {
    Color color;

    if (isOn) {
      color = Color(0xFFFCA311);
    } else {
      color = Color(0xFF14213D);
    }

    return Container(
      height: 40,
      width: 40,
      child: Icon(
        Icons.lightbulb,
        color: Colors.white,
      ),
      padding: EdgeInsets.all(20),
      color: color,
    );
  }
}

class KNXSpeedSlider extends StatefulWidget {
  @override
  _KNXSpeedSliderState createState() => _KNXSpeedSliderState();
}

class _KNXSpeedSliderState extends State<KNXSpeedSlider> {
  double currentValue = 1000;

  @override
  Widget build(BuildContext context) {
    return GweeboCard(
      child: Container(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            Text(
              "Speed",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text("Modifier la vitesse du chenillard"),
            Slider(
              inactiveColor: Theme.of(context).accentColor,
              activeColor: Theme.of(context).primaryColor,
              value: currentValue,
              min: 600,
              max: 2000,
              divisions: 8,
              onChanged: (double value) {
                setState(() => currentValue = value);
                knxRequest.requestToServer(
                    "modifierVitesseChenillard?vitesse=${value.toInt()}");
              },
            )
          ],
        ),
      ),
    );
  }
}

class KNXButton extends StatelessWidget {
  final String title;
  final String description;
  final Icon logo;
  final String pathToSend;

  KNXButton(
      {@required this.title,
      @required this.description,
      @required this.logo,
      @required this.pathToSend});

  @override
  Widget build(BuildContext context) {
    return GweeboCard(
      child: InkWell(
        onTap: () {
          if (!requestStatue) {
            showRequestWaiting(context, pathToSend);
          }
        },
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              Text(
                this.title,
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).primaryColor),
              ),
              Text(this.description),
              this.logo,
            ],
          ),
        ),
      ),
    );
  }

  void showRequestWaiting(BuildContext context, String path) {
    var overlayEntryRequestIn = OverlayEntry(builder: (context) {
      return new NotificationCard(
          description: "Envoi de la requête",
          logo: Padding(
            padding: const EdgeInsets.all(2.0),
            child: CircularProgressIndicator(
              valueColor: new AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ),
          color: Theme.of(context).accentColor,
          fromOutsideToInside: true);
    });

    var overlayEntryRequestOut = OverlayEntry(builder: (context) {
      return new NotificationCard(
          description: "Envoi de la requête",
          logo: Padding(
            padding: const EdgeInsets.all(2.0),
            child: CircularProgressIndicator(
              valueColor: new AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ),
          color: Theme.of(context).accentColor,
          fromOutsideToInside: false);
    });

    var overlayEntryValidIn = OverlayEntry(builder: (context) {
      return new NotificationCard(
          description: "Requête envoyée !",
          logo: Icon(Icons.check),
          color: Colors.greenAccent,
          fromOutsideToInside: true);
    });

    var overlayEntryValidOut = OverlayEntry(builder: (context) {
      return new NotificationCard(
          description: "Requête envoyée !",
          logo: Icon(Icons.check),
          color: Colors.greenAccent,
          fromOutsideToInside: false);
    });

    var overlayEntryErrorIn = OverlayEntry(builder: (context) {
      return new NotificationCard(
          description: "Erreur lors de l'envoi.",
          logo: Icon(Icons.error_outline),
          color: Colors.redAccent,
          fromOutsideToInside: true);
    });

    var overlayEntryErrorOut = OverlayEntry(builder: (context) {
      return new NotificationCard(
          description: "Erreur lors de l'envoi.",
          logo: Icon(Icons.error_outline),
          color: Colors.redAccent,
          fromOutsideToInside: false);
    });

    Overlay.of(context).insert(overlayEntryRequestIn);

    //future = knxRequest.playChenillard();

    knxRequest
        .requestToServer(path)
        .then((value) {
          print("Valeur du future : " + value.body.toString());
          if (value.body.isNotEmpty) {
            if (jsonDecode(value.body.toString())["statut"] == "realise") {
              Future.delayed(Duration(seconds: 1), () {
                overlayEntryRequestIn.remove();
                Overlay.of(context).insert(overlayEntryRequestOut);
                Future.delayed(Duration(milliseconds: 500), () {
                  Overlay.of(context).insert(overlayEntryValidIn);
                  Future.delayed(Duration(seconds: 2), () {
                    overlayEntryValidIn.remove();
                    Overlay.of(context).insert(overlayEntryValidOut);
                  });
                });
              });
            } else {
              Future.delayed(Duration(seconds: 1), () {
                overlayEntryRequestIn.remove();
                Overlay.of(context).insert(overlayEntryRequestOut);
                Future.delayed(Duration(milliseconds: 500), () {
                  Overlay.of(context).insert(overlayEntryErrorIn);
                  Future.delayed(Duration(seconds: 2), () {
                    overlayEntryErrorIn.remove();
                    Overlay.of(context).insert(overlayEntryErrorOut);
                  });
                });
              });
            }
          }
        })
        .timeout(Duration(seconds: 5))
        .onError((error, stackTrace) {
          Future.delayed(Duration(seconds: 1), () {
            overlayEntryRequestIn.remove();
            Overlay.of(context).insert(overlayEntryRequestOut);
            Future.delayed(Duration(milliseconds: 500), () {
              Overlay.of(context).insert(overlayEntryErrorIn);
              Future.delayed(Duration(seconds: 2), () {
                overlayEntryErrorIn.remove();
                Overlay.of(context).insert(overlayEntryErrorOut);
              });
            });
          });
        });
  }
}

class NotificationCard extends StatelessWidget {
  final String description;
  final Widget logo;
  final Color color;
  final bool fromOutsideToInside;

  NotificationCard(
      {@required this.description,
      @required this.logo,
      @required this.color,
      @required this.fromOutsideToInside});

  @override
  Widget build(BuildContext context) {
    double beginFrom;
    double endTo;

    if (this.fromOutsideToInside) {
      beginFrom = 0;
      endTo = 72;
    } else {
      beginFrom = 72;
      endTo = 0;
    }

    final size = MediaQuery.of(context).size;
    return PlayAnimation<double>(
      tween: new Tween(begin: beginFrom, end: endTo),
      duration: Duration(milliseconds: 400),
      curve: Curves.easeOut,
      builder: (context, child, value) => Positioned(
        width: 250,
        height: 56,
        top: size.height - value,
        left: size.width / 2 - 125,
        child: Material(
          color: Colors.transparent,
          child: Card(
            child: Container(
              padding: EdgeInsets.all(4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  AspectRatio(
                    aspectRatio: 2 / 2,
                    child: Center(
                      child: Container(
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            shape: BoxShape.rectangle, color: this.color),
                        child: this.logo,
                      ),
                    ),
                  ),
                  Text(
                    this.description,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
