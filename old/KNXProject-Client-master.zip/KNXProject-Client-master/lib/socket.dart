import 'dart:io';

import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class MySocket {
  static WebSocketChannel socket;

  static void connectSocket() async {
    socket = WebSocketChannel.connect(
        Uri.parse("ws://10.0.2.2:8080/getStatutLampe"));
  }

  static void sendData(String data) {
    print("Sending data : " + data);
    socket.sink.add(data);
  }

  static void closeConnection() {
    socket.sink.close();
  }
}
