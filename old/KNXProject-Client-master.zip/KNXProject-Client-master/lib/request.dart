import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

class KNXRequest {
  String url;

  KNXRequest({@required this.url});

  Future<http.Response> requestToServer(String path) {
    Uri link = Uri.parse(url + "/" + path);
    try {
      print("On rentre dans le get");
      return http.get(link);
    } on TimeoutException catch (e) {
      print("OULALA CA BUG");
      return Future.error(e);
    }
  }
}
